"""Verification Engine executing deterministic checks and semantic validation."""
import re
from typing import Dict, Any, List
from backend.core.logging_config import logger

REQUIRED_REPORT_SECTIONS = [
    "1. Research Objective",
    "2. Executive Summary",
    "3. Key Findings",
    "4. Topic-by-Topic Comparison",
    "5. Supporting Evidence and Source Links",
    "6. Limitations and Unresolved Questions",
    "7. Sources Consulted",
    "8. Execution Summary",
    "9. Verification Results",
]

class VerificationEngine:
    @staticmethod
    def verify_step_execution(
        step: Dict[str, Any],
        tool_output: Dict[str, Any],
        sources: List[Dict[str, Any]],
        evidences: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Validates the output of an individual step using deterministic integrity checks."""
        results = []
        tool_name = step.get("tool_name")
        step_id = step.get("id")

        if tool_name == "browser_page_extractor":
            # Check 1: Content non-empty
            content = tool_output.get("content", "")
            is_valid_content = bool(content and len(content.strip()) > 50)
            results.append({
                "step_id": step_id,
                "target_type": "step",
                "check_name": "page_content_non_empty",
                "is_passed": is_valid_content,
                "deterministic": True,
                "details": f"Extracted {len(content)} characters from target URL.",
            })

            # Check 2: HTTP status 200
            status_code = tool_output.get("status_code", 0)
            is_200 = (status_code == 200)
            results.append({
                "step_id": step_id,
                "target_type": "step",
                "check_name": "http_status_success",
                "is_passed": is_200,
                "deterministic": True,
                "details": f"Response status code: {status_code}.",
            })

            # Check 3: Domain and final URL resolved
            final_url = tool_output.get("final_url", "")
            has_url = bool(final_url and final_url.startswith("http"))
            results.append({
                "step_id": step_id,
                "target_type": "step",
                "check_name": "canonical_url_resolved",
                "is_passed": has_url,
                "deterministic": True,
                "details": f"Resolved canonical URL: {final_url}.",
            })

        elif tool_name == "web_search":
            results_list = tool_output.get("results", [])
            has_results = bool(results_list and len(results_list) > 0)
            results.append({
                "step_id": step_id,
                "target_type": "step",
                "check_name": "search_discovery_yield",
                "is_passed": has_results,
                "deterministic": True,
                "details": f"Discovered {len(results_list)} reference candidates.",
            })

        elif tool_name == "evidence_synthesizer":
            extracted = tool_output.get("evidences", [])
            has_ev = bool(extracted and len(extracted) > 0)
            results.append({
                "step_id": step_id,
                "target_type": "step",
                "check_name": "evidence_records_synthesized",
                "is_passed": has_ev,
                "deterministic": True,
                "details": f"Synthesized {len(extracted)} evidence records.",
            })

        return results

    @staticmethod
    def verify_final_report(
        report_markdown: str,
        sources: List[Dict[str, Any]],
        evidences: List[Dict[str, Any]],
        file_path: str,
    ) -> List[Dict[str, Any]]:
        """Verifies report structure, evidence citations, and file persistence."""
        results = []

        # Check 1: All 9 sections present
        missing_sections = []
        for sec in REQUIRED_REPORT_SECTIONS:
            # Match section title in markdown
            if sec.lower() not in report_markdown.lower():
                missing_sections.append(sec)
        
        all_sections_present = len(missing_sections) == 0
        results.append({
            "target_type": "report",
            "check_name": "all_nine_sections_present",
            "is_passed": all_sections_present,
            "deterministic": True,
            "details": "All 9 required sections present." if all_sections_present else f"Missing sections: {', '.join(missing_sections)}",
        })

        # Check 2: Evidence ID referential integrity
        # Check that evidence IDs mentioned in text (e.g. `EVID-001`) actually exist in evidences
        known_ids = {e["stable_id"] for e in evidences}
        found_ids = set(re.findall(r"EVID-\d{3}", report_markdown))
        orphan_ids = found_ids - known_ids
        
        referential_integrity = len(orphan_ids) == 0 and len(found_ids) > 0
        results.append({
            "target_type": "report",
            "check_name": "evidence_id_referential_integrity",
            "is_passed": referential_integrity,
            "deterministic": True,
            "details": f"Found {len(found_ids)} cited IDs; 0 orphans." if referential_integrity else f"Orphan cited IDs: {orphan_ids}",
        })

        # Check 3: Downloadable file exists on disk
        import os
        file_exists = os.path.exists(file_path) and os.path.getsize(file_path) > 100
        results.append({
            "target_type": "report",
            "check_name": "downloadable_report_file_exists",
            "is_passed": file_exists,
            "deterministic": True,
            "details": f"File verified on disk at {file_path} ({os.path.getsize(file_path) if file_exists else 0} bytes).",
        })

        # Check 4: Sources consulted alignment
        sources_aligned = len(sources) > 0 and any(s.get("domain", "") in report_markdown for s in sources)
        results.append({
            "target_type": "report",
            "check_name": "source_domains_referenced",
            "is_passed": sources_aligned,
            "deterministic": True,
            "details": f"Verified {len(sources)} distinct domain references in report body.",
        })

        return results

verifier = VerificationEngine()
