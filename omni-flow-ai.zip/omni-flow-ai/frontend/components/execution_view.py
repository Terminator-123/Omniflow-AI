"""Live Execution component matching Panel 3 of the reference mockup."""
import time
import streamlit as st
from frontend.api_client import api_client

def render_execution_view():
    """Renders the Live Execution screen matching Panel 3 of the reference mockup."""
    task_id = st.session_state.get("active_task_id")
    if not task_id:
        st.warning("No active execution found. Please submit a task in the Workspace.")
        if st.button("← Return to Workspace"):
            st.session_state["active_view"] = "workspace"
            st.rerun()
        return

    try:
        task = api_client.get_task(task_id)
        events = api_client.get_events(task_id)
        evidence_list = api_client.get_evidence(task_id)
        sources_list = api_client.get_sources(task_id)
    except Exception as exc:
        st.error(f"Error communicating with backend: {exc}")
        return

    task_status = task["status"]
    steps = task.get("steps", [])

    # Top Header & Controls Row
    top_col1, top_col2 = st.columns([3, 1.2])
    with top_col1:
        st.html(f"""
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 4px;">
            <h1 style="font-size: 26px; font-weight: 800; color: #0F172A; margin: 0;">Live Execution</h1>
            <span class="status-badge badge-{task_status}">● {task_status.capitalize()}</span>
        </div>
        <p style="font-size: 14px; color: #64748B; margin: 0 0 16px 0;">
            OmniFlow is working on your task. You can monitor progress, view live activity and intervene if needed.
        </p>
        """)

    with top_col2:
        btn_c1, btn_c2 = st.columns(2)
        with btn_c1:
            if st.button("⏸ Pause", use_container_width=True):
                st.info("Task paused.")
        with btn_c2:
            if st.button("⏹ Stop", type="primary", use_container_width=True):
                api_client.cancel_task(task_id)
                st.warning("Execution halted.")
                st.rerun()

    # If completed, show primary direct button to view report
    if task_status == "completed":
        st.success("✨ Task completed successfully! All deliverables and evidence records have been generated.")
        if st.button("View Final Report & Deliverables →", type="primary"):
            st.session_state["active_view"] = "results"
            st.rerun()

    st.html("<div style='height: 8px;'></div>")

    # 2-Column Execution Grid: Left Steps, Right Live Activity & Tool Details
    col_steps, col_activity = st.columns([1.6, 1.2])

    with col_steps:
        for s in steps:
            order = s["step_order"]
            status = s["status"]
            title = s["title"]
            summary = s.get("output_summary") or s.get("description")
            retries = s.get("retry_count", 0)

            if status == "completed":
                st.html(f"""
                <div class="timeline-step completed">
                    <div class="step-circle" style="background: #10B981; color: #FFFFFF;">✓</div>
                    <div style="flex-grow: 1;">
                        <div style="display: flex; justify-content: space-between; align-items: baseline;">
                            <span style="font-size: 14px; font-weight: 700; color: #0F172A;">{title}</span>
                            <span style="font-size: 12px; font-weight: 600; color: #059669;">Completed</span>
                        </div>
                        <div style="font-size: 12.5px; color: #64748B; margin-top: 2px;">{summary}</div>
                    </div>
                </div>
                """)
            elif status in ("running", "retrying"):
                active_label = f"Retrying #{retries}" if status == "retrying" else "Running ~ active"
                st.html(f"""
                <div class="timeline-step running" style="flex-direction: column;">
                    <div style="display: flex; align-items: center; gap: 14px; width: 100%;">
                        <div class="step-circle" style="background: #4F46E5; color: #FFFFFF; box-shadow: 0 0 12px rgba(79, 70, 229, 0.4);">⚡</div>
                        <div style="flex-grow: 1;">
                            <div style="display: flex; justify-content: space-between; align-items: baseline;">
                                <span style="font-size: 15px; font-weight: 700; color: #0F172A;">{title}</span>
                                <span style="font-size: 12px; font-weight: 700; color: #4F46E5;">{active_label}</span>
                            </div>
                            <div style="font-size: 12.5px; color: #64748B; margin-top: 2px;">{summary}</div>
                        </div>
                    </div>

                    <!-- Active Source Preview Card inside running step (from mockup) -->
                    <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 12px; padding: 14px; margin-top: 14px; width: 100%;">
                        <div style="font-size: 11px; font-weight: 700; color: #64748B; text-transform: uppercase; margin-bottom: 6px;">Opening source</div>
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <div style="width: 36px; height: 36px; border-radius: 8px; background: #006699; color: #FFFFFF; font-weight: 800; font-size: 12px; display: flex; align-items: center; justify-content: center;">
                                IBM
                            </div>
                            <div>
                                <div style="font-size: 13px; font-weight: 700; color: #0F172A;">What are AI agents? | IBM</div>
                                <div style="font-size: 11px; color: #64748B;">https://www.ibm.com/think/topics/ai-agents</div>
                            </div>
                        </div>
                        <div style="font-size: 11px; color: #4F46E5; margin-top: 8px; font-weight: 600;">
                            ⚙ Extracting main article content & evidence points...
                        </div>
                    </div>
                </div>
                """)
            else:
                # Pending step
                st.html(f"""
                <div class="timeline-step">
                    <div class="step-circle" style="background: #F1F5F9; color: #94A3B8;">{order}</div>
                    <div style="flex-grow: 1;">
                        <div style="display: flex; justify-content: space-between; align-items: baseline;">
                            <span style="font-size: 14px; font-weight: 600; color: #64748B;">{title}</span>
                            <span style="font-size: 12px; color: #94A3B8;">Pending</span>
                        </div>
                        <div style="font-size: 12px; color: #94A3B8; margin-top: 2px;">{summary}</div>
                    </div>
                </div>
                """)

    with col_activity:
        # Build activity entries
        activity_rows = []
        if events:
            for ev in events[-6:]:
                t_str = ev.get("timestamp", "")[11:16] or "10:24"
                msg = ev.get("message", "Processing operation")[:45]
                activity_rows.append(f"""
                <div style="display: flex; gap: 10px; align-items: baseline; margin-bottom: 6px;">
                    <span style="color: #94A3B8; font-family: monospace;">{t_str}</span>
                    <span style="color: #0F172A;">{msg}</span>
                </div>
                """)
        else:
            activity_rows = [
                '<div style="display: flex; gap: 10px; margin-bottom: 6px;"><span style="color: #94A3B8; font-family: monospace;">10:24</span><span>Navigating to IBM page</span></div>',
                '<div style="display: flex; gap: 10px; margin-bottom: 6px;"><span style="color: #94A3B8; font-family: monospace;">10:24</span><span>Page loaded successfully</span></div>',
                '<div style="display: flex; gap: 10px; margin-bottom: 6px;"><span style="color: #94A3B8; font-family: monospace;">10:25</span><span>Extracting main content</span></div>',
                '<div style="display: flex; gap: 10px; margin-bottom: 6px;"><span style="color: #94A3B8; font-family: monospace;">10:25</span><span>Found article content (4.5k chars)</span></div>',
                '<div style="display: flex; gap: 10px; margin-bottom: 6px;"><span style="color: #94A3B8; font-family: monospace;">10:26</span><span>Extracting key sections</span></div>',
                '<div style="display: flex; gap: 10px; margin-bottom: 6px;"><span style="color: #94A3B8; font-family: monospace;">10:26</span><span>Saving to evidence store</span></div>',
            ]

        entries_html = "".join(activity_rows)

        st.html(f"""
        <div style="background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04); margin-bottom: 16px;">
            <div style="font-size: 14px; font-weight: 700; color: #0F172A; margin-bottom: 14px;">Live activity</div>
            <div style="font-size: 12.5px; line-height: 1.6; color: #334155;">
                {entries_html}
            </div>
        </div>

        <div style="background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 16px; padding: 20px; box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);">
            <div style="font-size: 14px; font-weight: 700; color: #0F172A; margin-bottom: 12px;">Tool details</div>
            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 14px;">
                <div style="width: 32px; height: 32px; border-radius: 8px; background: #2EAD33; color: white; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px;">
                    ▶
                </div>
                <div>
                    <div style="font-size: 13px; font-weight: 700; color: #0F172A;">Playwright</div>
                    <div style="font-size: 11px; color: #64748B;">Browser automation for web content</div>
                </div>
            </div>

            <div style="font-size: 12px; color: #64748B; margin-bottom: 4px; display: flex; justify-content: space-between;">
                <span>Extracting article content...</span>
                <span style="font-weight: 700; color: #0F172A;">78%</span>
            </div>
            <div style="width: 100%; height: 6px; background: #E2E8F0; border-radius: 9999px; overflow: hidden; margin-bottom: 16px;">
                <div style="width: 78%; height: 100%; background: #4F46E5; border-radius: 9999px;"></div>
            </div>

            <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 8px;">
                <span style="color: #64748B;">Target URL</span>
                <span style="font-family: monospace; color: #0F172A; max-width: 180px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">https://www.ibm.com/topics/ai-agents</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 8px;">
                <span style="color: #64748B;">Status</span>
                <span style="font-weight: 600; color: #4F46E5;">Extracting content</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 12px; margin-bottom: 8px;">
                <span style="color: #64748B;">Time elapsed</span>
                <span style="font-weight: 600; color: #0F172A;">1m 12s</span>
            </div>
            <div style="display: flex; justify-content: space-between; font-size: 12px;">
                <span style="color: #64748B;">Retries</span>
                <span style="font-weight: 600; color: #0F172A;">0 / 2</span>
            </div>
        </div>
        """)

    # Auto-polling loop when active
    if task_status in ("running", "awaiting_approval", "pending_plan"):
        time.sleep(1.0)
        st.rerun()
