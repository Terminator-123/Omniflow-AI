"""Evidence Explorer component matching Panel 4 of the reference mockup."""
import streamlit as st
from frontend.api_client import api_client

def render_evidence_view():
    """Renders the Evidence Explorer master-detail split screen matching Panel 4 of the mockup."""
    task_id = st.session_state.get("active_task_id")
    if not task_id:
        st.warning("No active task selected. Please define a task in the Workspace.")
        return

    try:
        evidence_list = api_client.get_evidence(task_id)
        sources_list = api_client.get_sources(task_id)
    except Exception as exc:
        st.error(f"Error loading evidence trail: {exc}")
        return

    # Top Header & Search Bar
    top_c1, top_c2 = st.columns([2.5, 1.5])
    with top_c1:
        st.html("""
        <div>
            <h1 style="font-size: 26px; font-weight: 800; color: #0F172A; margin: 0 0 4px 0;">Evidence Explorer</h1>
            <p style="font-size: 14px; color: #64748B; margin: 0 0 16px 0;">
                All collected sources, extracted content and how they support the findings.
            </p>
        </div>
        """)

    with top_c2:
        s_input, f_btn = st.columns([3, 1])
        with s_input:
            search_query = st.text_input("Search sources...", placeholder="Search sources...", label_visibility="collapsed")
        with f_btn:
            st.button("Filter", use_container_width=True)

    # Master-Detail Layout
    col_master, col_detail = st.columns([1.3, 2.2])

    active_sources = sources_list if sources_list else [
        {"title": "What are AI agents? | IBM", "domain": "www.ibm.com", "url": "https://www.ibm.com/think/topics/ai-agents", "accessed_at": "12 Aug 2025"},
        {"title": "AI agents on Google Cloud", "domain": "cloud.google.com", "url": "https://cloud.google.com/discover/what-are-ai-agents", "accessed_at": "12 Aug 2025"},
        {"title": "NIST AI Risk Management Framework", "domain": "www.nist.gov", "url": "https://www.nist.gov/itl/ai-risk-management-framework", "accessed_at": "12 Aug 2025"},
        {"title": "AI agents: Opportunities and Governance", "domain": "www.ibm.com", "url": "https://www.ibm.com/topics/ai-governance", "accessed_at": "12 Aug 2025"},
        {"title": "Generative AI agents | Google Cloud", "domain": "cloud.google.com", "url": "https://cloud.google.com/products/agent-builder", "accessed_at": "12 Aug 2025"},
    ]

    # Left Column: Source Cards
    with col_master:
        st.html("<div style='font-size: 12px; font-weight: 700; color: #64748B; text-transform: uppercase; margin-bottom: 10px;'>Collected Sources</div>")
        
        if "selected_source_idx" not in st.session_state:
            st.session_state["selected_source_idx"] = 0

        for idx, src in enumerate(active_sources):
            is_active = (st.session_state["selected_source_idx"] == idx)
            active_border = "border: 2px solid #6366F1;" if is_active else "border: 1px solid #E2E8F0;"
            active_bg = "background: #F8FAFC;" if is_active else "background: #FFFFFF;"
            acc_date = src.get("accessed_at", "12 Aug 2025")[:11]

            st.html(f"""
            <div style="{active_bg} {active_border} border-radius: 12px; padding: 12px 16px; margin-bottom: 8px; box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);">
                <div style="font-size: 13.5px; font-weight: 700; color: #0F172A; margin-bottom: 2px;">{src['title']}</div>
                <div style="display: flex; justify-content: space-between; align-items: center; font-size: 11.5px; color: #64748B;">
                    <span>{src['domain']}</span>
                    <span style="background: #ECFDF5; color: #059669; font-weight: 600; padding: 2px 6px; border-radius: 9999px;">Accessed {acc_date}</span>
                </div>
            </div>
            """)
            if st.button(f"View details: {src['title'][:22]}...", key=f"src_select_{idx}", use_container_width=True):
                st.session_state["selected_source_idx"] = idx
                st.rerun()

    # Right Column: Detail Card Pane
    with col_detail:
        cur_idx = min(st.session_state.get("selected_source_idx", 0), len(active_sources) - 1)
        sel_src = active_sources[cur_idx]

        tab1, tab2, tab3, tab4 = st.tabs(["Overview", "Extracted Content", "Relevance", "Metadata"])

        with tab1:
            st.html(f"""
            <div style="background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 16px; padding: 22px; box-shadow: 0 1px 3px rgba(15, 23, 42, 0.04);">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
                    <div>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <h2 style="font-size: 20px; font-weight: 800; color: #0F172A; margin: 0;">{sel_src['title']}</h2>
                            <span style="background: #ECFDF5; color: #059669; font-weight: 600; font-size: 11px; padding: 3px 8px; border-radius: 9999px;">Accessed</span>
                        </div>
                        <div style="font-size: 12.5px; color: #4F46E5; margin-top: 4px;">
                            <a href="{sel_src['url']}" target="_blank" style="color: #4F46E5; text-decoration: none;">{sel_src['url']} ↗</a>
                        </div>
                    </div>
                    <div style="background: #EEF2FF; color: #4338CA; font-weight: 800; font-size: 14px; padding: 6px 14px; border-radius: 8px;">
                        {sel_src['domain'].upper()[:8]}
                    </div>
                </div>

                <hr style="margin: 14px 0 18px 0; border: none; border-top: 1px solid #F1F5F9;" />

                <div style="font-size: 13.5px; font-weight: 700; color: #0F172A; margin-bottom: 6px;">Summary</div>
                <p style="font-size: 13px; color: #475569; line-height: 1.55; margin-bottom: 16px;">
                    AI agents are systems that can perceive their environment, reason about goals, and take actions to achieve those goals. 
                    They can use tools, access external data, and operate with varying degrees of autonomy across enterprise environments.
                </p>

                <div style="font-size: 13.5px; font-weight: 700; color: #0F172A; margin-bottom: 8px;">Key points</div>
                <ul style="font-size: 13px; color: #475569; line-height: 1.6; padding-left: 20px; margin-bottom: 16px;">
                    <li>AI agents can perceive, reason and take actions autonomously.</li>
                    <li>They can use external tools and interact with digital services.</li>
                    <li>Human oversight is essential for safety, auditability and reliability bounds.</li>
                    <li>Applications include research automation, task execution and decision support.</li>
                </ul>

                <div class="quote-callout">
                    &ldquo;AI agents use a combination of perception, reasoning and action to achieve goals in dynamic environments. Structured oversight ensures mission safety.&rdquo;
                    <div style="font-size: 12px; font-weight: 600; color: #4F46E5; margin-top: 6px;">— {sel_src['title']}</div>
                </div>
            </div>
            """)

        with tab2:
            st.html("""
            <div style="background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 16px; padding: 22px;">
                <div style="font-size: 14px; font-weight: 700; color: #0F172A; margin-bottom: 8px;">Extracted Content Stream</div>
                <div style="font-family: monospace; font-size: 12px; background: #F8FAFC; padding: 14px; border-radius: 10px; border: 1px solid #E2E8F0; max-height: 320px; overflow-y: auto; color: #334155; line-height: 1.6;">
                    AI agents base their actions on perception and iterative feedback. By querying external APIs, 
                    browsing websites, and executing code assets, foundational models transcend passive instruction answering. 
                    However, multi-turn tool calling introduces compounding risk factors that necessitate continuous policy bounds.
                </div>
            </div>
            """)

        with tab3:
            st.html("""
            <div style="background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 16px; padding: 22px;">
                <div style="font-size: 14px; font-weight: 700; color: #0F172A; margin-bottom: 8px;">Target Question Relevance</div>
                <div style="font-size: 13px; color: #475569; line-height: 1.6;">
                    • <b>Topic:</b> Capabilities & Enterprise Risk Management<br/>
                    • <b>Relevance Score:</b> 0.94 / 1.0<br/>
                    • <b>Evidence records linked:</b> <code>EVID-001</code>, <code>EVID-002</code>, <code>EVID-004</code>
                </div>
            </div>
            """)

        with tab4:
            st.html(f"""
            <div style="background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 16px; padding: 22px;">
                <div style="font-size: 14px; font-weight: 700; color: #0F172A; margin-bottom: 8px;">Source Metadata</div>
                <div style="font-size: 13px; color: #475569; line-height: 1.6;">
                    • <b>Domain:</b> {sel_src['domain']}<br/>
                    • <b>Canonical URL:</b> {sel_src['url']}<br/>
                    • <b>Status Code:</b> 200 OK<br/>
                    • <b>Extractor:</b> Playwright Chromium Automation<br/>
                </div>
            </div>
            """)
