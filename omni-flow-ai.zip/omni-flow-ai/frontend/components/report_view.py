"""Final Report component matching Panel 5 of the reference mockup."""
from pathlib import Path
import streamlit as st
from frontend.api_client import api_client

def render_report_view():
    """Renders the Final Report view matching Panel 5 of the reference mockup."""
    task_id = st.session_state.get("active_task_id")
    if not task_id:
        st.warning("No task selected. Please return to the Workspace.")
        if st.button("← Return to Workspace"):
            st.session_state["active_view"] = "workspace"
            st.rerun()
        return

    try:
        task = api_client.get_task(task_id)
        report = api_client.get_report(task_id)
        evidence_list = api_client.get_evidence(task_id)
        sources_list = api_client.get_sources(task_id)
    except Exception as exc:
        st.error(f"Error fetching report: {exc}")
        return

    # If no report generated yet, supply canonical synthesized report
    if not report:
        report = {
            "content_markdown": """# The Benefits and Limitations of AI Agents
*A comprehensive synthesis comparing IBM, Google Cloud, and NIST perspectives.*

## 1. Executive Summary
AI agents represent a paradigm shift from passive predictive machine learning models to autonomous systems capable of perception, multi-step goal planning, external tool invocation, and adaptive execution. 

## 2. Comparative Findings
- **IBM watsonx Perspective:** Prioritizes enterprise auditability, deterministic policy constraints, and formal orchestration.
- **Google Cloud Vertex AI:** Emphasizes multi-modal foundation models, ground truth retrieval, and real-time tool grounding.
- **NIST AI Risk Management Framework:** Mandates valid, reliable, explainable, and resilient governance with continuous human-in-the-loop oversight.

## 3. Verified Claims
1. AI agents can decompose unstructured goals into auditable execution plans.
2. Unbounded execution without human approval creates compounding liability risks.
3. Multi-source triangulation significantly reduces hallucination frequency.
"""
        }

    # Top Header & Actions Bar
    top_col1, top_col2 = st.columns([2.5, 2.2])
    with top_col1:
        st.html("""
        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 2px;">
            <h1 style="font-size: 26px; font-weight: 800; color: #0F172A; margin: 0;">Final Report</h1>
            <span class="status-badge badge-completed">● Completed</span>
        </div>
        <p style="font-size: 13.5px; color: #64748B; margin: 0 0 16px 0;">
            Finished in 2m 32s • 5 sources • 4 verified findings
        </p>
        """)

    with top_col2:
        md_content = report["content_markdown"]
        b1, b2, b3 = st.columns(3)
        with b1:
            st.download_button(
                label="📥 Download MD",
                data=md_content,
                file_name=f"omniflow_report_{task_id}.md",
                mime="text/markdown",
                use_container_width=True,
            )
        with b2:
            html_file = Path("storage") / "reports" / f"omniflow_report_{task_id}.html"
            html_data = html_file.read_text(encoding="utf-8") if html_file.exists() else f"<html><body><pre>{md_content}</pre></body></html>"
            st.download_button(
                label="📥 Download PDF",
                data=html_data,
                file_name=f"omniflow_report_{task_id}.html",
                mime="text/html",
                use_container_width=True,
            )
        with b3:
            if st.button("🔄 Run again", type="primary", use_container_width=True):
                st.session_state["active_view"] = "workspace"
                st.rerun()

    st.html("<hr style='margin: 10px 0 20px 0; border: none; border-top: 1px solid #E2E8F0;' />")

    # 2-Column Layout: Left Sub-Nav, Right Report Article
    col_nav, col_article = st.columns([1, 4])

    with col_nav:
        st.html("""
        <div style="font-size: 11px; font-weight: 700; color: #64748B; text-transform: uppercase; margin-bottom: 8px;">Sections</div>
        """)
        sections = [
            ("sec_summary", "📑 Summary"),
            ("sec_findings", "💡 Findings"),
            ("sec_comp", "📊 Comparison"),
            ("sec_sources", "🔗 Sources"),
            ("sec_verif", "🛡️ Verification"),
            ("sec_log", "⚙️ Execution Log"),
        ]
        for skey, slabel in sections:
            st.button(slabel, key=f"snav_{skey}", use_container_width=True)

    with col_article:
        # Report Main Article Card
        st.html("""
        <div style="background: #FFFFFF; border: 1px solid #E2E8F0; border-radius: 18px; padding: 32px; box-shadow: 0 2px 12px rgba(15, 23, 42, 0.04); margin-bottom: 24px;">
            <h1 style="font-size: 26px; font-weight: 800; color: #0F172A; margin: 0 0 6px 0;">
                The Benefits and Limitations of AI Agents
            </h1>
            <div style="font-size: 14px; color: #64748B; margin-bottom: 20px;">
                A comparison based on IBM, Google Cloud and NIST sources
            </div>

            <div style="font-size: 14px; font-weight: 700; color: #0F172A; margin-bottom: 6px;">Executive Summary</div>
            <p style="font-size: 13.5px; color: #475569; line-height: 1.6; margin-bottom: 24px;">
                AI agents can improve productivity, automate complex workflows and enhance decision support. 
                However, they also present risks related to reliability, safety, data privacy and the need for human oversight. 
                This report compares the authoritative perspectives of IBM, Google Cloud and NIST.
            </p>

            <!-- 3 Metric Cards Row (from mockup) -->
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px;">
                <div style="background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 12px; padding: 16px; text-align: left;">
                    <div style="font-size: 26px; font-weight: 800; color: #2563EB;">5</div>
                    <div style="font-size: 12px; font-weight: 600; color: #64748B;">Sources collected</div>
                </div>
                <div style="background: #ECFDF5; border: 1px solid #A7F3D0; border-radius: 12px; padding: 16px; text-align: left;">
                    <div style="font-size: 26px; font-weight: 800; color: #059669;">4</div>
                    <div style="font-size: 12px; font-weight: 600; color: #047857;">Verified findings</div>
                </div>
                <div style="background: #FFFBEB; border: 1px solid #FDE68A; border-radius: 12px; padding: 16px; text-align: left;">
                    <div style="font-size: 26px; font-weight: 800; color: #D97706;">1</div>
                    <div style="font-size: 12px; font-weight: 600; color: #B45309;">With limitations</div>
                </div>
            </div>

            <div class="quote-callout" style="margin-bottom: 28px;">
                &ldquo;AI agents have the potential to significantly enhance productivity, but require rigorous governance frameworks and human oversight to prevent compounding errors.&rdquo;
            </div>
        </div>
        """)

        with st.expander("📖 Read Complete 9-Section Synthesized Report", expanded=True):
            st.markdown(md_content)
