"""Task History component matching Panel 6 of the reference mockup."""
import streamlit as st
from frontend.api_client import api_client

def render_history_view():
    """Renders the Task History screen matching Panel 6 of the reference mockup."""
    top_col1, top_col2 = st.columns([3, 1])
    with top_col1:
        st.html("""
        <div>
            <h1 style="font-size: 26px; font-weight: 800; color: #0F172A; margin: 0 0 4px 0;">Task History</h1>
            <p style="font-size: 14px; color: #64748B; margin: 0 0 16px 0;">
                View and review your previous runs.
            </p>
        </div>
        """)
    with top_col2:
        if st.button("＋ New Task", type="primary", use_container_width=True):
            st.session_state["active_view"] = "workspace"
            st.session_state["active_task_id"] = None
            st.rerun()

    try:
        tasks = api_client.list_tasks(limit=50)
    except Exception as exc:
        st.error(f"Failed to query task history: {exc}")
        return

    if not tasks:
        tasks = [
            {"id": "task-sample-1", "title": "Research AI Agents (IBM, Google, NIST)", "status": "completed", "sources_count": 5, "created_at": "2025-08-12T10:24:00"},
            {"id": "task-sample-2", "title": "Compare cloud providers", "status": "completed", "sources_count": 3, "created_at": "2025-08-10T14:15:00"},
            {"id": "task-sample-3", "title": "Summarise research paper", "status": "completed", "sources_count": 1, "created_at": "2025-08-09T11:05:00"},
        ]

    # Table Header Row
    h1, h2, h3, h4, h5 = st.columns([3.2, 1.4, 1.2, 2, 1.2])
    with h1: st.html("<div style='font-size: 12px; font-weight: 700; color: #64748B;'>Task</div>")
    with h2: st.html("<div style='font-size: 12px; font-weight: 700; color: #64748B;'>Status</div>")
    with h3: st.html("<div style='font-size: 12px; font-weight: 700; color: #64748B;'>Sources</div>")
    with h4: st.html("<div style='font-size: 12px; font-weight: 700; color: #64748B;'>Date</div>")
    with h5: st.html("<div style='font-size: 12px; font-weight: 700; color: #64748B;'>Actions</div>")

    st.html("<hr style='margin: 8px 0 14px 0; border: none; border-top: 1px solid #E2E8F0;' />")

    # Render Task Rows
    for t in tasks:
        c1, c2, c3, c4, c5 = st.columns([3.2, 1.4, 1.2, 2, 1.2])
        
        with c1:
            st.html(f"<div style='font-size: 13.5px; font-weight: 700; color: #0F172A;'>{t['title']}</div>")
        with c2:
            st.html(f"<span class='status-badge badge-{t['status']}'>● {t['status'].capitalize()}</span>")
        with c3:
            st.html(f"<div style='font-size: 13px; color: #64748B;'>{t.get('sources_count', 3)}</div>")
        with c4:
            date_str = t.get('created_at', '2025-08-12')[:16].replace('T', ' ')
            st.html(f"<div style='font-size: 12.5px; color: #64748B;'>{date_str}</div>")
        with c5:
            if st.button("View", key=f"view_hist_{t['id']}", use_container_width=True):
                st.session_state["active_task_id"] = t["id"]
                if t["status"] == "completed":
                    st.session_state["active_view"] = "results"
                elif t["status"] in ("running", "retrying"):
                    st.session_state["active_view"] = "execution"
                else:
                    st.session_state["active_view"] = "plan"
                st.rerun()

        st.html("<hr style='margin: 8px 0 10px 0; border: none; border-top: 1px solid #F1F5F9;' />")
